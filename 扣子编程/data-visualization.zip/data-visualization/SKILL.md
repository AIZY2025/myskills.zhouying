---
name: data-visualization
description: 生成符合WCAG对比度标准的可视化图表代码；当用户需要数据展示、报告配图或交互式图表时使用
dependency:
  python:
    - colormath==3.0.0
---

# 数据可视化技能

## 任务目标
本技能用于：生成符合无障碍设计标准的高对比度数据可视化图表
能力包含：图表类型选择、配色方案优化、布局规范化、对比度验证
触发条件：用户需要创建图表、数据可视化展示、报告配图、仪表盘设计

## 前置准备
- 依赖说明：scripts脚本所需的依赖包
  ```
  colormath==1.1.2
  ```

## 设计原则
- 对比度要求：所有文本与背景对比度 ≥ 4.5:1（WCAG AA标准），大文本 ≥ 3:1
- 配色规范：避免纯色对比，使用HSL色相差异化+亮度调节确保可读性
- 布局规范：网格化布局，统一间距（8px倍数），左对齐优先
- 图表清晰：每张图表包含标题、图例、坐标轴标签

## 操作步骤

### 步骤1：需求分析
- 明确数据类型（数值、分类、时间序列、地理数据）
- 确定图表用途（趋势分析、对比展示、分布统计）
- 识别目标受众（专业用户、普通用户、移动端用户）

### 步骤2：选择图表类型
根据数据类型和用途选择：
- **柱状图**：分类数据对比，适合2-10个类别
- **折线图**：时间序列趋势，适合连续数据
- **饼图**：占比展示，不超过5个扇区
- **散点图**：相关性分析，双变量关系
- **热力图**：多维度数据展示

### 步骤3：配置配色方案
- 使用 [references/high-contrast-theme.css](references/high-contrast-theme.css) 中的推荐配色
- 调用 `scripts/validate-contrast.py --foreground <颜色> --background <颜色>` 验证对比度
- 确保色盲友好（使用色相+饱和度双重编码）

### 步骤4：生成图表代码
- 使用 [assets/html-template.html](assets/html-template.html) 作为基础模板
- 引入 [assets/grid-layout.css](assets/grid-layout.css) 确保布局整齐
- 参考 [references/echarts-config.md](references/echarts-config.md) 配置图表参数
- 添加响应式设计（使用百分比或flex布局）

### 步骤5：验证与优化
- 使用对比度验证脚本检查关键配色
- 测试不同屏幕尺寸下的显示效果
- 确保图表在黑白打印时仍可读

## 资源索引

### 必要脚本
- [scripts/validate-contrast.py](scripts/validate-contrast.py)（用途：验证颜色对比度是否符合WCAG AA标准）

### 领域参考
- [references/wcag-contrast.md](references/wcag-contrast.md)（何时读取：需要了解对比度计算方法和配色推荐时）
- [references/echarts-config.md](references/echarts-config.md)（何时读取：配置ECharts图表参数时）
- [references/layout-principles.md](references/layout-principles.md)（何时读取：设计图表布局时）

### 输出资产
- [assets/html-template.html](assets/html-template.html)（直接用于生成HTML结构）
- [assets/high-contrast-theme.css](assets/high-contrast-theme.css)（直接用于应用高对比度配色）
- [assets/grid-layout.css](assets/grid-layout.css)（直接用于实现网格化布局）

## 注意事项
- 优先使用智能体能力理解需求和生成图表配置逻辑
- 仅在需要验证颜色对比度时调用脚本
- 确保图表组件间距统一（使用8px倍数）
- 避免使用纯红/纯绿/纯蓝作为主要颜色（色盲不可见）
- 移动端简化图表元素（减少数据点数量）

## 使用示例

### 示例1：生成销售趋势折线图
- 功能说明：展示月度销售额趋势
- 执行方式：智能体生成ECharts配置 + 模板渲染
- 关键要点：
  - 使用高对比度配色（深蓝背景+白色线条）
  - 添加数据点标签和悬停提示
  - 确保坐标轴标签清晰可读

### 示例2：多维度对比柱状图
- 功能说明：对比不同产品类别的销售额
- 执行方式：智能体生成配置 + 验证对比度
- 关键要点：
  - 使用差异化配色（蓝、绿、橙、紫）
  - 调用脚本验证文本与背景对比度
  - 添加网格辅助线和图例

### 示例3：响应式仪表盘布局
- 功能说明：多图表组合展示
- 执行方式：智能体使用grid-layout.css实现
- 关键要点：
  - 2x2网格布局
  - 统一间距16px
  - 响应式断点（<768px单列显示）

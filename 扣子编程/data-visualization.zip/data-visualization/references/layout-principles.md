# 图表布局原则

## 目录
1. [布局基础](#布局基础)
2. [间距规范](#间距规范)
3. [对齐方式](#对齐方式)
4. [网格系统](#网格系统)
5. [多图表组合](#多图表组合)
6. [响应式断点](#响应式断点)

## 概览
本文档提供图表布局设计原则，确保多个图表组件排列整齐、视觉协调。

## 布局基础

### 核心原则
1. **一致性**：所有图表使用统一的间距、字体、配色
2. **对齐**：所有元素遵循网格对齐
3. **留白**：适当留白避免拥挤，提升可读性
4. **层次**：通过大小、颜色、位置建立视觉层次

### 基本布局结构
```
┌─────────────────────────────────────┐
│          页面标题区                  │
├─────────────────────────────────────┤
│  ┌─────────┐  ┌─────────┐          │
│  │ 图表A   │  │ 图表B   │          │
│  └─────────┘  └─────────┘          │
│  ┌─────────┐  ┌─────────┐          │
│  │ 图表C   │  │ 图表D   │          │
│  └─────────┘  └─────────┘          │
└─────────────────────────────────────┘
```

## 间距规范

### 8px基础间距系统
| 场景 | 间距值 | 用途 |
|------|--------|------|
| 超小间距 | 4px | 图标与文字间距 |
| 小间距 | 8px | 同组元素间距 |
| 中间距 | 16px | 不同组元素间距 |
| 大间距 | 24px | 区块间距 |
| 超大间距 | 32px | 主要分区间距 |

### 图表内间距
```css
.chart-container {
  padding: 16px;        /* 图表内边距 */
  margin: 16px;         /* 图表外边距 */
  gap: 16px;            /* 网格间距 */
}
```

### 文字间距
```css
.title {
  margin-bottom: 16px;  /* 标题下方间距 */
  line-height: 1.5;     /* 行高 */
  letter-spacing: 0.5px; /* 字间距 */
}
```

## 对齐方式

### 左对齐优先
```css
/* 推荐的左对齐布局 */
.chart-wrapper {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  text-align: left;
}
```

### 居中对齐适用场景
- 页面主标题
- 图表内部居中内容（饼图）
- 按钮组

### 对齐一致性规则
- 所有图表标题左对齐
- 所有图例左对齐或底部居中
- 坐标轴标签与坐标轴对齐
- 数据标签与数据点对齐

## 网格系统

### 12列网格布局
```css
.grid-container {
  display: grid;
  grid-template-columns: repeat(12, 1fr);
  gap: 16px;
}

/* 单列布局 */
.grid-full {
  grid-column: span 12;
}

/* 两列布局 */
.grid-half {
  grid-column: span 6;
}

/* 三列布局 */
.grid-third {
  grid-column: span 4;
}

/* 四列布局 */
.grid-quarter {
  grid-column: span 3;
}
```

### 常用布局模式

#### 2x2网格（4个图表）
```css
.dashboard-grid {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 16px;
}
```

#### 1+2布局（1大+2小）
```css
.hybrid-layout {
  display: grid;
  grid-template-columns: 2fr 1fr;
  grid-template-rows: auto auto;
  gap: 16px;
}

.main-chart {
  grid-column: 1;
  grid-row: span 2;
}
```

#### 1+3布局（1大+3小）
```css
.sidebar-layout {
  display: grid;
  grid-template-columns: 3fr 1fr;
  gap: 16px;
}
```

## 多图表组合

### 图表对齐要点
1. 所有图表底部对齐（基线对齐）
2. 所有图表标题垂直对齐
3. 所有图例水平对齐
4. 坐标轴标签对齐

### 图表高度统一
```css
.chart-card {
  height: 400px;      /* 固定高度确保整齐 */
  min-height: 300px;  /* 最小高度 */
}

.chart-inner {
  height: calc(100% - 60px); /* 减去标题高度 */
}
```

### 边框和阴影
```css
.chart-card {
  border: 1px solid #E0E0E0;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  padding: 16px;
}
```

## 响应式断点

### 断点定义
| 断点 | 屏幕宽度 | 布局调整 |
|------|----------|----------|
| 移动端 | < 768px | 单列布局 |
| 平板 | 768px - 1024px | 两列布局 |
| 桌面 | > 1024px | 三列/四列布局 |

### 响应式布局示例
```css
/* 移动端：单列 */
@media (max-width: 768px) {
  .grid-container {
    grid-template-columns: 1fr;
  }
}

/* 平板：两列 */
@media (min-width: 768px) and (max-width: 1024px) {
  .grid-container {
    grid-template-columns: repeat(2, 1fr);
  }
}

/* 桌面：三列 */
@media (min-width: 1024px) {
  .grid-container {
    grid-template-columns: repeat(3, 1fr);
  }
}
```

### 移动端优化
```css
@media (max-width: 768px) {
  .chart-container {
    padding: 12px;  /* 减少内边距 */
    margin: 8px;    /* 减少外边距 */
  }

  .chart-title {
    font-size: 14px;  /* 缩小字体 */
    margin-bottom: 8px;
  }

  .chart-inner {
    height: 250px;    /* 减少高度 */
  }
}
```

## 布局检查清单

### 完成检查
- [ ] 所有图表使用统一的间距（16px基础）
- [ ] 所有图表高度一致（或遵循比例）
- [ ] 所有标题左对齐
- [ ] 所有图例对齐方式一致
- [ ] 网格间距均匀
- [ ] 边框和阴影样式一致
- [ ] 移动端布局适配完成
- [ ] 平板端布局适配完成
- [ ] 桌面端布局适配完成
- [ ] 页面滚动条合理

### 常见问题
❌ 图表高度不一致导致参差不齐
❌ 间距不统一（有的8px，有的16px）
❌ 标题对齐方式混乱（有的左对齐，有的居中）
❌ 移动端图表过小无法查看
❌ 多图表组合时未使用网格系统

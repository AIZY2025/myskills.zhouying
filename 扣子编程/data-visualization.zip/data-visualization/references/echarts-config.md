# ECharts配置详解

## 目录
1. [基础配置](#基础配置)
2. [常用图表类型](#常用图表类型)
3. [样式调整](#样式调整)
4. [响应式设计](#响应式设计)
5. [完整示例](#完整示例)

## 概览
本文档提供ECharts图表库的配置指南，涵盖常用图表类型、样式优化和无障碍设计配置。

## 基础配置

### 最小配置模板
```javascript
option = {
  title: {
    text: '图表标题',
    left: 'center',
    textStyle: {
      color: '#333333',
      fontSize: 18
    }
  },
  tooltip: {
    trigger: 'axis'
  },
  legend: {
    data: ['系列名称'],
    top: 30
  },
  grid: {
    left: '3%',
    right: '4%',
    bottom: '3%',
    containLabel: true
  },
  xAxis: {
    type: 'category',
    data: ['A', 'B', 'C', 'D', 'E']
  },
  yAxis: {
    type: 'value'
  },
  series: [{
    name: '系列名称',
    type: 'bar',
    data: [10, 20, 30, 40, 50]
  }]
};
```

## 常用图表类型

### 1. 柱状图
```javascript
series: [{
  type: 'bar',
  name: '销售额',
  data: [120, 200, 150, 80, 70],
  itemStyle: {
    color: '#0052CC'
  },
  label: {
    show: true,
    position: 'top',
    color: '#333333'
  }
}]
```

### 2. 折线图
```javascript
series: [{
  type: 'line',
  name: '趋势',
  data: [120, 200, 150, 80, 70],
  itemStyle: {
    color: '#FF6B35'
  },
  lineStyle: {
    width: 3
  },
  symbol: 'circle',
  symbolSize: 8
}]
```

### 3. 饼图
```javascript
series: [{
  type: 'pie',
  radius: ['40%', '70%'],
  data: [
    { value: 335, name: '类别A' },
    { value: 310, name: '类别B' },
    { value: 234, name: '类别C' }
  ],
  label: {
    show: true,
    formatter: '{b}: {d}%'
  },
  itemStyle: {
    borderRadius: 5
  }
}]
```

### 4. 散点图
```javascript
series: [{
  type: 'scatter',
  name: '数据点',
  data: [[10, 20], [20, 30], [30, 10]],
  symbolSize: 10,
  itemStyle: {
    color: '#00875A'
  }
}]
```

### 5. 热力图
```javascript
series: [{
  type: 'heatmap',
  data: [[0, 0, 10], [0, 1, 20], [1, 0, 30]],
  itemStyle: {
    emphasis: {
      shadowBlur: 10,
      shadowColor: 'rgba(0, 0, 0, 0.5)'
    }
  }
}]
```

## 样式调整

### 高对比度配色
```javascript
option = {
  backgroundColor: '#FFFFFF',
  title: {
    textStyle: {
      color: '#000000' // 黑色标题，对比度21:1
    }
  },
  tooltip: {
    backgroundColor: '#1A1A1A',
    textStyle: {
      color: '#FFFFFF' // 白色文字，对比度15.9:1
    }
  },
  xAxis: {
    axisLine: {
      lineStyle: {
        color: '#333333'
      }
    },
    axisLabel: {
      color: '#333333' // 深灰标签
    }
  },
  yAxis: {
    axisLine: {
      lineStyle: {
        color: '#333333'
      }
    },
    axisLabel: {
      color: '#333333'
    }
  }
};
```

### 网格线和辅助线
```javascript
yAxis: {
  splitLine: {
    show: true,
    lineStyle: {
      color: '#E0E0E0',
      type: 'dashed'
    }
  }
}
```

### 图例样式
```javascript
legend: {
  textStyle: {
    color: '#333333',
    fontSize: 14
  },
  itemWidth: 20,
  itemHeight: 14
}
```

## 响应式设计

### 自适应容器
```javascript
// 初始化时
const chart = echarts.init(document.getElementById('chart-container'));

// 监听窗口变化
window.addEventListener('resize', function() {
  chart.resize();
});
```

### 移动端优化
```javascript
option = {
  grid: {
    left: '10%',
    right: '5%',
    bottom: '10%'
  },
  title: {
    textStyle: {
      fontSize: 14 // 移动端缩小字体
    }
  }
};
```

## 完整示例

### 销售趋势折线图
```javascript
const option = {
  backgroundColor: '#FFFFFF',
  title: {
    text: '2024年月度销售额趋势',
    left: 'center',
    textStyle: {
      color: '#000000',
      fontSize: 18,
      fontWeight: 'bold'
    }
  },
  tooltip: {
    trigger: 'axis',
    backgroundColor: '#1A1A1A',
    textStyle: {
      color: '#FFFFFF',
      fontSize: 14
    },
    formatter: function(params) {
      return `${params[0].name}<br/>销售额: ${params[0].value}万元`;
    }
  },
  legend: {
    data: ['销售额'],
    top: 30,
    textStyle: {
      color: '#333333',
      fontSize: 14
    }
  },
  grid: {
    left: '3%',
    right: '4%',
    bottom: '3%',
    containLabel: true
  },
  xAxis: {
    type: 'category',
    data: ['1月', '2月', '3月', '4月', '5月', '6月'],
    axisLine: {
      lineStyle: {
        color: '#333333'
      }
    },
    axisLabel: {
      color: '#333333',
      fontSize: 12
    }
  },
  yAxis: {
    type: 'value',
    name: '销售额（万元）',
    nameTextStyle: {
      color: '#333333'
    },
    axisLine: {
      lineStyle: {
        color: '#333333'
      }
    },
    axisLabel: {
      color: '#333333'
    },
    splitLine: {
      lineStyle: {
        color: '#E0E0E0',
        type: 'dashed'
      }
    }
  },
  series: [{
    name: '销售额',
    type: 'line',
    data: [120, 132, 101, 134, 90, 230],
    itemStyle: {
      color: '#0052CC'
    },
    lineStyle: {
      width: 3
    },
    symbol: 'circle',
    symbolSize: 8,
    label: {
      show: true,
      position: 'top',
      color: '#333333',
      fontSize: 12
    }
  }]
};
```

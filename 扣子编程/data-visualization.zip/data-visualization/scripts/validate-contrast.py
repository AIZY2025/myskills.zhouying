#!/usr/bin/env python3
"""
颜色对比度验证工具
验证两个颜色之间的对比度是否符合WCAG 2.1标准
"""

import argparse
import sys
from colormath.color_objects import sRGBColor, LabColor
from colormath.color_conversions import convert_color
from colormath.color_diff import delta_e_cie2000


def hex_to_rgb(hex_color):
    """
    将十六进制颜色转换为RGB值

    Args:
        hex_color: 十六进制颜色字符串（如 "#FFFFFF" 或 "FFFFFF"）

    Returns:
        RGB元组 (r, g, b)，值范围0-255
    """
    hex_color = hex_color.lstrip('#')
    if len(hex_color) != 6:
        raise ValueError(f"无效的十六进制颜色: {hex_color}")

    try:
        r = int(hex_color[0:2], 16)
        g = int(hex_color[2:4], 16)
        b = int(hex_color[4:6], 16)
        return (r, g, b)
    except ValueError as e:
        raise ValueError(f"无效的十六进制颜色: {hex_color}") from e


def get_relative_luminance(rgb):
    """
    计算颜色的相对亮度（根据WCAG 2.1标准）

    Args:
        rgb: RGB元组 (r, g, b)，值范围0-255

    Returns:
        相对亮度值（0-1之间）
    """
    r, g, b = rgb

    # 将sRGB值转换为线性RGB
    def linearize(value):
        value = value / 255.0
        if value <= 0.03928:
            return value / 12.92
        else:
            return ((value + 0.055) / 1.055) ** 2.4

    r_linear = linearize(r)
    g_linear = linearize(g)
    b_linear = linearize(b)

    # 计算相对亮度
    luminance = 0.2126 * r_linear + 0.7152 * g_linear + 0.0722 * b_linear

    return luminance


def calculate_contrast_ratio(l1, l2):
    """
    计算对比度（根据WCAG 2.1标准）

    Args:
        l1: 较亮颜色的相对亮度
        l2: 较暗颜色的相对亮度

    Returns:
        对比度比值（如 4.5 表示 4.5:1）
    """
    lighter = max(l1, l2)
    darker = min(l1, l2)

    contrast = (lighter + 0.05) / (darker + 0.05)
    return contrast


def check_wcag_compliance(contrast, text_size="normal"):
    """
    检查对比度是否符合WCAG标准

    Args:
        contrast: 对比度比值
        text_size: 文本大小（"normal" 或 "large"）

    Returns:
        包含合规性信息的字典
    """
    result = {
        "contrast": contrast,
        "wcag_aa": False,
        "wcag_aaa": False,
        "rating": "不合规",
        "recommendation": ""
    }

    if text_size == "large":
        # 大文本（≥18pt或14pt加粗）
        aa_threshold = 3.0
        aaa_threshold = 4.5
    else:
        # 普通文本
        aa_threshold = 4.5
        aaa_threshold = 7.0

    if contrast >= aaa_threshold:
        result["wcag_aa"] = True
        result["wcag_aaa"] = True
        result["rating"] = "优秀 (AAA)"
        result["recommendation"] = "对比度优秀，满足WCAG AAA级标准"
    elif contrast >= aa_threshold:
        result["wcag_aa"] = True
        result["rating"] = "合格 (AA)"
        result["recommendation"] = "对比度合格，满足WCAG AA级标准"
    else:
        result["wcag_aa"] = False
        result["wcag_aaa"] = False
        result["rating"] = "不合规"
        if text_size == "large":
            result["recommendation"] = f"对比度不达标，建议提升至 {aa_threshold}:1 以上"
        else:
            result["recommendation"] = f"对比度不达标，建议提升至 {aa_threshold}:1 以上"

    return result


def format_color_info(hex_color, rgb, luminance):
    """
    格式化颜色信息

    Args:
        hex_color: 十六进制颜色
        rgb: RGB值
        luminance: 相对亮度

    Returns:
        格式化的字符串
    """
    return f"{hex_color} (RGB: {rgb}, 亮度: {luminance:.3f})"


def main():
    parser = argparse.ArgumentParser(
        description="验证颜色对比度是否符合WCAG 2.1标准",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 验证深蓝色和白色的对比度
  python validate_contrast.py --foreground "#0052CC" --background "#FFFFFF"

  # 验证大文本的对比度
  python validate_contrast.py -f "#333333" -b "#FFFFFF" --text-size large

  # 批量验证多个配色
  python validate_contrast.py -f "#0052CC" -b "#FFFFFF" -f "#FF6B35" -b "#FFFFFF"
        """
    )

    parser.add_argument(
        "-f", "--foreground",
        required=True,
        action="append",
        help="前景色（十六进制，如 #FFFFFF 或 FFFFFF）"
    )

    parser.add_argument(
        "-b", "--background",
        required=True,
        action="append",
        help="背景色（十六进制，如 #FFFFFF 或 FFFFFF）"
    )

    parser.add_argument(
        "-t", "--text-size",
        choices=["normal", "large"],
        default="normal",
        help="文本大小（normal: 普通文本, large: 大文本≥18pt或14pt加粗），默认: normal"
    )

    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="显示详细信息"
    )

    args = parser.parse_args()

    # 验证输入数量
    if len(args.foreground) != len(args.background):
        print("错误：前景色和背景色的数量必须相同", file=sys.stderr)
        sys.exit(1)

    # 验证每组颜色对比度
    all_passed = True
    for i, (fg_hex, bg_hex) in enumerate(zip(args.foreground, args.background), 1):
        try:
            # 转换颜色
            fg_rgb = hex_to_rgb(fg_hex)
            bg_rgb = hex_to_rgb(bg_hex)

            # 计算相对亮度
            fg_luminance = get_relative_luminance(fg_rgb)
            bg_luminance = get_relative_luminance(bg_rgb)

            # 计算对比度
            contrast = calculate_contrast_ratio(fg_luminance, bg_luminance)

            # 检查WCAG合规性
            compliance = check_wcag_compliance(contrast, args.text_size)

            # 输出结果
            if args.verbose:
                print(f"\n配色组合 {i}:")
                print(f"  前景色: {format_color_info(fg_hex, fg_rgb, fg_luminance)}")
                print(f"  背景色: {format_color_info(bg_hex, bg_rgb, bg_luminance)}")
                print(f"  对比度: {contrast:.2f}:1")
                print(f"  评级: {compliance['rating']}")
                print(f"  WCAG AA: {'✓ 通过' if compliance['wcag_aa'] else '✗ 不通过'}")
                print(f"  WCAG AAA: {'✓ 通过' if compliance['wcag_aaa'] else '✗ 不通过'}")
                print(f"  建议: {compliance['recommendation']}")
            else:
                status = "✓" if compliance['wcag_aa'] else "✗"
                print(f"{status} {fg_hex} vs {bg_hex}: {contrast:.2f}:1 ({compliance['rating']})")

            if not compliance['wcag_aa']:
                all_passed = False

        except ValueError as e:
            print(f"错误：{e}", file=sys.stderr)
            sys.exit(1)

    # 返回退出码
    sys.exit(0 if all_passed else 1)


if __name__ == "__main__":
    main()
